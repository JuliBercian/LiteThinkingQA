package ui.google;

import net.serenitybdd.screenplay.targets.Target;
import net.thucydides.core.pages.PageObject;

public class GoogleHomePage extends PageObject {

    public static Target SEARCH_FIELD = Target.the("search field").locatedBy("#APjFqb");

}
